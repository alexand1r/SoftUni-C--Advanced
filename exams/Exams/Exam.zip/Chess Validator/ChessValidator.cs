﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chess_Validator
{
    class ChessValidator
    {
        public static int ROWS = 8, COLS = 8;
        static void Main(string[] args)
        {
            char[][] board = new char[8][];
            for (int row = 0; row < ROWS; row++)
            {
                board[row] = Console.ReadLine().Replace(",", "").ToCharArray();
            }

            string cmd = Console.ReadLine();
            while (!cmd.Equals("END"))
            {
                char symbol = cmd[0];
                int startRow = (int)Char.GetNumericValue(cmd[1]);
                int startCol = (int)Char.GetNumericValue(cmd[2]);
                int endRow = (int)Char.GetNumericValue(cmd[4]);
                int endCol = (int)Char.GetNumericValue(cmd[5]);

                if (!board[startRow][startCol].Equals(symbol))
                {
                    Console.WriteLine("There is no such a piece!");
                    cmd = Console.ReadLine();
                    continue;
                }

                bool isInvalidMove = false;
                switch (symbol)
                {
                    case 'K':
                        if (Math.Abs(endRow - startRow) > 1 &&
                            Math.Abs(endCol - startCol) > 1)
                            isInvalidMove = true;
                        break;
                    case 'R':
                        if (startRow != endRow && startCol != endCol)
                            isInvalidMove = true;
                        break;
                    case 'B':
                        if (Math.Abs(startRow - endRow) 
                            != Math.Abs(startCol - endCol))
                            isInvalidMove = true;
                        break;
                    case 'Q':
                        if ((startRow != endRow && startCol != endCol) &&
                            Math.Abs(startRow - endRow) != Math.Abs(startCol - endCol))
                            isInvalidMove = true;
                        break;
                    case 'N':
                        if ((Math.Abs(startRow - endRow) != 2 && Math.Abs(startCol - endCol) != 1) &&
                            (Math.Abs(startCol - endCol) != 2 && Math.Abs(startRow - endRow) != 1))
                            isInvalidMove = true;
                        break;
                    case 'P':
                        if (startCol != endCol || startRow - endRow != 1)
                            isInvalidMove = true;
                        break;
                }

                if (isInvalidMove)
                {
                    Console.WriteLine("Invalid Move!");
                    cmd = Console.ReadLine();
                    continue;
                }

                if (endRow < 0 || endRow > ROWS - 1 || endCol < 0 || endCol > COLS - 1)
                {
                    Console.WriteLine("Move go out of board!");
                    cmd = Console.ReadLine();
                    continue;
                }

                board[startRow][startCol] = 'x';
                board[endRow][endCol] = symbol;

                cmd = Console.ReadLine();
            }
            
            //PrintBoard(board);
        }

        private static void PrintBoard(char[][] board)
        {
            for (int i = 0; i < ROWS; i++)
            {
                Console.WriteLine(string.Join(" ", board[i]));
            }
        }
    }
}
